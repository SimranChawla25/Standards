package com.browserstack;
import org.testng.Assert;
import org.testng.annotations.Test;

public class BStackDemoTest extends SeleniumTest {
    @Test(priority = 0)
    public void launchWebsite() throws InterruptedException {
    try {	
    driver.get("https://www.flipkart.com/");
    System.out.println("Title is: " + driver.getTitle());
    Assert.assertEquals(driver.getTitle(), "Online Shopping Site for Mobiles, Electronics, Furniture, Grocery, Lifestyle, Books & More. Best Offers!");
    }catch(Exception e) {
    System.out.println("An error occurred while launching the website: " + e.getMessage());
    }
    }
}
