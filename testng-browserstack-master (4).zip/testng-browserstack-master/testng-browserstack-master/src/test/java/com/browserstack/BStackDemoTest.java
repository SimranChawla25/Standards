package com.browserstack;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class BStackDemoTest extends SeleniumTest {
    @Test(priority = 0)
    public void launchWebsite() throws InterruptedException {
    try {	
    driver.get("https://www.flipkart.com/");
    System.out.println("Title is: " + driver.getTitle());
    Assert.assertEquals(driver.getTitle(), "Online Shopping Site for Mobiles, Electronics, Furniture, Grocery, Lifestyle, Books & More. Best Offers!");
    }catch(Exception e) {
    System.out.println("An error occurred while launching the website: " + e.getMessage());
    }
    }
    @Test(priority=1)
	public void searchProduct() throws InterruptedException {
    	try {
		driver.findElement(By.xpath("//input[@title='Search for Products, Brands and More']")).sendKeys("Samsung Galaxy S10");
		driver.findElement(By.className("_2iLD__")).click();
		Assert.assertTrue(driver.getCurrentUrl().contains("q=Samsung%20Galaxy%20S10"));
    	}catch(Exception e) {
    		System.out.println("An error occurred during searchProduct test: " + e.getMessage());	
    	}
	}
    @Test(priority=2)
    public void clickMobileCategory() throws InterruptedException{
    	try {
    	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
    	System.out.println("mobile category:");
    	WebElement mobilesLink = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Mobiles']")));
        mobilesLink.click();
        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//div[@class='_1D76KH']/a")));
        List<WebElement> brandLinks = driver.findElements(By.xpath("//div[@class='_1D76KH']/a"));
        Assert.assertTrue(brandLinks.size() > 0, "Navigation to Mobiles category failed");
    	}catch(Exception e) {
    	System.out.println("An error occurred while navigating to mobile category: " + e.getMessage());
    	}
    }
    @Test(priority=3)
    public void applyFilters() throws InterruptedException {
    	try {
    	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
    	wait.until(ExpectedConditions.elementToBeClickable(By.className("_3879cV"))).click();
    	Thread.sleep(2000);
        wait.until(ExpectedConditions.elementToBeClickable(By.className("_3U-Vxu"))).click();
    	String filteredURL = driver.getCurrentUrl();
    	Assert.assertTrue(filteredURL.toLowerCase().contains("samsung") && filteredURL.toLowerCase().contains("fassured"), 
                "Filters are not applied successfully");
    	}catch(Exception e) {
    	System.out.println("An error occurred while applying filters: " + e.getMessage());	
    	}
    }
    @Test(priority=4)
    public void sortPrice() throws InterruptedException {
    	try {
         WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
         WebElement sortButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='_10UF8M'][3]")));
         sortButton.click();
         Thread.sleep(2000);
        List<WebElement> productPrices = driver.findElements(By.className("_30jeq3"));
        boolean sorted = true;
        for (int i = 0; i < productPrices.size() - 1; i++) {
            String price1 = productPrices.get(i).getText().replaceAll("[^0-9]", ""); // Extracting numeric part of price
            String price2 = productPrices.get(i + 1).getText().replaceAll("[^0-9]", ""); // Extracting numeric part of price
            if (Integer.parseInt(price1) < Integer.parseInt(price2)) {
                sorted = false;
                break;
            }
        }
        Assert.assertTrue(sorted, "Products are not sorted by price");
    	}catch(Exception e) {
    	System.out.println("An error occurred while applying sort price high to low: " + e.getMessage());		
    	}
    }
    @Test(priority=5)
    public void readAllResultsOnPage() {
    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    	List<WebElement> allProducts = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className("_2kHMtA")));
    	 Assert.assertFalse(allProducts.isEmpty(), "No products found on the page");
    	for (int i = 0; i < allProducts.size(); i++) {
    	    WebElement product = allProducts.get(i);
    	    try {
    	        System.out.println(product.getText());
    	        System.out.println("*********************************************************************");
    	    } catch (StaleElementReferenceException e) {
    	        // Handle stale element reference exception by refreshing the element list
    	        allProducts = driver.findElements(By.className("_2kHMtA"));
    	        WebElement freshProduct = allProducts.get(i);
    	        System.out.println(freshProduct.getText());
    	        System.out.println("*********************************************************************");
    	    }
    	}}
    @Test(priority=6)
    public void readParameterResultsOnPage() {
        // Wait for the product results to load
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        List<WebElement> allProducts = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className("_2kHMtA")));
        Assert.assertFalse(allProducts.isEmpty(), "No products found on the page");
        for (WebElement product : allProducts) {
            try {
                // Extract product details
                String productName = product.findElement(By.className("_4rR01T")).getText();
                String displayPrice = product.findElement(By.className("_30jeq3")).getText();
                String productDetailsLink = product.findElement(By.className("_1fQZEK")).getAttribute("href");

                // Print product details on the console
                System.out.println("Product Name: " + productName);
                System.out.println("Display Price: " + displayPrice);
                System.out.println("Link to Product Details Page: " + productDetailsLink);
                System.out.println("*********************************************************************");
            } catch (StaleElementReferenceException e) {
                // Handle stale element reference exception by refreshing the element list
                allProducts = driver.findElements(By.className("_2kHMtA"));
                WebElement freshProduct = allProducts.get(allProducts.indexOf(product));
                String productName = freshProduct.findElement(By.className("_4rR01T")).getText();
                String displayPrice = freshProduct.findElement(By.className("_30jeq3")).getText();
                String productDetailsLink = freshProduct.findElement(By.className("_1fQZEK")).getAttribute("href");

                // Print product details on the console
                System.out.println("Product Name: " + productName);
                System.out.println("Display Price: " + displayPrice);
                System.out.println("Link to Product Details Page: " + productDetailsLink);
                System.out.println("*********************************************************************");
            }
        }
    }
}
